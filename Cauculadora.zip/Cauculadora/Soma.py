def soma (num1,num2):
    soma = num1 + num2
    return soma