def sub(num1,num2):
    sub = num1 - num2
    return sub