def verificarZero (num):
    if num == 0:
        return True
    else :
        return False