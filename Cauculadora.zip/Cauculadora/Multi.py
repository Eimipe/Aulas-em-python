def multi(num1,num2):
    multi = num1 * num2
    return multi